System logs and indexes
