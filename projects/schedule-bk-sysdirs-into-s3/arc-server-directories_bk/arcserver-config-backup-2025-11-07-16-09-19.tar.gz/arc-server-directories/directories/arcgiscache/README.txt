Tile cache placeholder
