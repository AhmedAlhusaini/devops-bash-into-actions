Geoprocessing job data
